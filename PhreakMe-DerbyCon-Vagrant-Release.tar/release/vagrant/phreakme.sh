!#/bin/bash
sudo apt-get -y install asterisk
sudo rm /etc/asterisk/* -r
sudo cp /phreakme/etc_asterisk/* /etc/asterisk/
sudo cp /phreakme-rest/* /var/www/ -R
sudo service apache2 stop
sudo rm -r /etc/apache2/*
sudo cp /phreakme/etc_apache2/* /etc/apache2/ -R
sudo rm /etc/ssl/* -r
sudo cp /phreakme/etc_ssl/* -r /etc/ssl/
sudo cp /phreakme/agi-bin/* /usr/share/asterisk/agi-bin/ -r
sudo cp /phreakme/opt_phreakme/phreakme/ /opt/ -R

# got to get the permissions and web serivce up
sudo chmod 777 /usr/share/asterisk/agi-bin/
sudo chmod 777 /opt/phreakme/skel/generated/ -R
sudo ln -s /var/spool/asterisk/outgoing /opt/phreakme/
sudo chmod 777 /opt/phreakme/skel/outgoing/ -R
sudo usermod -a -G www-data asterisk
sudo usermod -a -G www-data vagrant
sudo usermod -a -G vagrant www-data
sudo usermod -a -G vagrant asterisk
sudo usermod -a -G asterisk www-data
sudo usermod -a -G asterisk vagrant

sudo service apache2 start
sudo service asterisk restart
ln -s /var/spool/asterisk/outgoing /opt/phreakme/skel/
