<?php

$recordings_dir = "/opt/phreakme/recordings/";

$config['trunk'] = ""; // your trunk here
$config['phreak_root'] = "/opt/phreakme";
$config['recordings_dir'] = $config['phreak_root'] . "/recordings/";
$config['phreak_targets'] = $config['phreak_root'] . "/targets.txt";

$config['cidnum'] =  "1111111111"; // default number
$config['cid'] = "<1111111111>"; // default number in <>'s

?>
